# Nhóm 3 — Portfolio và trang tin

Mở `index.html`. Portfolio Tuần 5 và nội dung trang tin Tuần 4 nằm chung trong một trang.

CSS, JavaScript và ảnh nền được nhúng trong HTML, nên chỉ mở một file vẫn có giao diện và tương tác. `style.css` và `script.js` là bản mã nguồn tương ứng để đọc/nộp bài; khi sửa các bản này cần đồng bộ lại phần nhúng trong HTML.

Không có thư mục nhom3 hay ZIP con. AOS/Animate.css vẫn được khai báo qua CDN; khi không có mạng, CSS và JavaScript nội bộ đảm nhiệm giao diện và hiệu ứng dự phòng.

Thành viên: Trần Ngọc Huy (125001758), Lê Văn Khoa (125001668), Nguyễn Minh Nhật (125001448).
