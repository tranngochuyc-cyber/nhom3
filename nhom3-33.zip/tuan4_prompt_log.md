# PROMPT LOG — TUẦN 4: DESIGN SYSTEM & RESPONSIVE

## Thông tin nhóm
- Trần Ngọc Huy — MSSV: 125001758 — Trưởng nhóm / phụ trách chính
- Lê Văn Khoa — MSSV: 125001668
- Nguyễn Minh Nhật — MSSV: 125001448

## Prompt 1 — Cấu trúc Mobile
Hãy đóng vai chuyên gia UI/UX. Viết HTML5 và CSS3 theo tư duy Mobile First cho trang tin tức. Ở mobile dưới 600px: thiết kế 1 cột, header/logo căn giữa hợp lý, có hamburger menu, sidebar ẩn, danh sách tin hiển thị một cột. Không dùng kích thước bố cục cố định gây tràn màn hình.

## Prompt 2 — Tablet (600px+)
Thêm Media Query cho màn hình từ 600px. Dùng CSS Grid chuyển danh sách bài viết từ 1 cột thành 2 cột. Header hiển thị navigation đơn giản, sidebar vẫn ẩn. Giữ khoảng cách bằng gap và dùng rem/% thay cho căn chỉnh cứng.

## Prompt 3 — Desktop (1024px+)
Thêm Media Query từ 1024px. Layout desktop gồm content chính và sidebar bên phải, navigation đầy đủ kèm search bar. Hero lớn hơn, sidebar hiển thị danh sách tin đọc nhiều. Không dùng float hoặc position tuyệt đối để dựng bố cục chính.

## Prompt 4 — Breakpoint Challenge
Tạo khu vực Chuyên mục bằng CSS Grid: 1 cột trên mobile, 2 cột trên tablet và 4 cột trên desktop. Bảo đảm không overlap, không overflow và khoảng cách đồng nhất.

## Prompt 5 — Design System Refactoring
Refactor CSS: trích xuất màu primary, primary-dark, secondary, các màu xám/nền, spacing, radius và shadow thành CSS Variables trong :root. Thay các giá trị lặp lại bằng biến và giữ code dễ đọc.

## Prompt 6 — Kiểm tra cuối
Kiểm tra toàn bộ HTML/CSS theo Mobile First. Xác nhận viewport meta, max-width container, responsive grid, menu theo breakpoint, sidebar desktop, font co giãn và không có chiều rộng cố định 1200px gây vỡ layout.


## Prompt bổ sung — Checklist hoàn thành Tuần 4
Kiểm tra toàn bộ website theo checklist: CSS Variables cho màu và khoảng cách; meta viewport; loại bỏ horizontal scroll; ảnh/card responsive; font Mobile tối thiểu 16px; touch target tối thiểu 44px; chuẩn hóa các mốc Mobile, Tablet 768px và Desktop 1024px. Giữ code rõ ràng và tránh tạo quá nhiều breakpoint.
