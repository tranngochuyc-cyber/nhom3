# Kết quả kiểm tra — 05/10/2026

## Đã chạy và đạt

- `node --check script.js`: JavaScript hợp lệ về cú pháp.
- Phân tích HTML bằng jsdom: ID không trùng, liên kết nội bộ có đích, các file nội bộ tồn tại.
- Đủ 2 thẻ lật, 3 thanh kỹ năng, 5 section fade-up.
- Phân tích CSS bằng PostCSS: không có lỗi cú pháp parser.
- Kiểm thử DOM: menu mở/đóng, Escape đóng, chọn liên kết đóng menu.
- Kiểm thử DOM: nút lật thẻ thay đổi trạng thái hai chiều.
- Kiểm thử DOM: spinner hiện, nút gửi khóa trong lúc chờ, mở khóa và hiện thông báo minh họa sau 1,2 giây.
- Kiểm thử DOM: khởi tạo fallback khi thiếu AOS; bỏ fallback khi reduced motion.
- Kiểm thử kết nối AOS bằng đối tượng giả lập: init được gọi và bật lớp điều khiển. Đây không phải kiểm thử thư viện AOS thực từ CDN.

## Chưa xác minh trong phiên này

- Không chạy được Chromium: môi trường thiếu trình duyệt; tải bản đầy đủ và headless shell đều nhận gói không hợp lệ. Do đó **chưa có kiểm tra hình ảnh, độ mượt, responsive hay tràn màn hình bằng trình duyệt thật**.
- Chưa xác minh truy cập thực tế CDN AOS/Animate.css. Mã đã có fallback.
- Chưa đẩy GitHub vì chưa có URL repository.

## Kiểm tra trên máy trước khi nộp

1. Mở `index.html`, kiểm tra chữ gõ, nút Liên hệ pulse, thanh kỹ năng.
2. Cuộn qua banner và các section: kiểm tra parallax desktop, fade-up.
3. Hover và nhấn thẻ dự án; dùng Tab + Enter để lật.
4. Thu màn hình xuống 390px: mở/đóng menu, kiểm tra chữ không tràn.
5. Điền form hợp lệ, bấm gửi: spinner chạy rồi thông báo chưa gửi email.
6. Tắt mạng và tải lại: nội dung vẫn đọc được, menu và form vẫn hoạt động.
7. Bật reduced motion trong hệ điều hành: chuyển động được tắt.
