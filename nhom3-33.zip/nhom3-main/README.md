# Nhóm 3 — Tuần 5: Hiệu ứng chuyển động & thư viện hiệu ứng

Portfolio của Trần Ngọc Huy, phát triển từ bài Tuần 3 được cung cấp.

| Thành viên | MSSV | Vai trò trong mã nguồn gốc |
|---|---|---|
| Trần Ngọc Huy | 125001758 | Trưởng nhóm / phụ trách chính |
| Lê Văn Khoa | 125001668 | Thành viên |
| Nguyễn Minh Nhật | 125001448 | Thành viên |

## Chạy bài

Giải nén, mở `index.html` bằng Chrome/Edge hoặc dùng VS Code Live Server. Không cần cài npm.
Có Internet để tải AOS và Animate.css qua CDN. Khi CDN không truy cập được, nội dung vẫn hiển thị; hiệu ứng cuộn dùng IntersectionObserver dự phòng. Ảnh nền SVG được đóng gói sẵn.

## Phân tích và đối chiếu đề

Đề yêu cầu nâng cấp portfolio với đủ **Hover, Keyframes, Scroll**, thực hành trên lớp, sáu bài tại nhà, nhật ký AI và cập nhật GitHub nhánh `feature/animation` với commit rõ ràng.

| Yêu cầu | Đã triển khai | Cách quan sát |
|---|---|---|
| CSS transition / micro-interaction | Nút gửi: hover nâng 3px, đổi nền, tăng bóng; active scale(.95), cubic-bezier | Rê chuột và giữ nút gửi |
| Loading spinner | Vòng tròn border-top khác màu, spin 360 độ, linear infinite | Điền đủ biểu mẫu và bấm gửi; loading 1,2 giây |
| AOS scroll reveal | AOS CDN, `data-aos="fade-up"`, init once; dự phòng offline | Cuộn đến các section bên dưới |
| Thư viện ngoài | AOS và Animate.css qua CDN | Animate.css fadeIn cho thông báo kết thúc |
| Refactoring | Dịch chuyển bằng transform; reveal bằng transform/opacity | Xem `style.css`; không animate top/left/margin |
| 1. Floating action button | Nút Liên hệ cố định góc dưới phải; keyframes phóng nhẹ | Bấm để tới biểu mẫu |
| 2. Card flip | Thẻ dự án rotateY(180deg), perspective, backface-visibility | Hover trên máy tính; nhấn/chạm/Enter trên điện thoại hoặc bàn phím |
| 3. Typing effect | Câu “Tôi là một Web Developer.” dùng CSS steps, không dùng JS gõ chữ | Tải lại trang |
| 4. Parallax image | Banner nền SVG, background-attachment: fixed trên desktop | Cuộn trên máy tính; mobile dùng scroll để ổn định |
| 5. Hamburger menu | 3 gạch chuyển thành X bằng transition transform/opacity | Màn hình ≤900px, bấm menu; Escape đóng |
| 6. Skill bar animation | Thanh HTML 90%, CSS 80%, JS 65% chạy từ 0 | Tải trang, thanh chạy bằng scaleX; số liệu minh họa |
| Prompt log | `week5_prompts.md` | Có yêu cầu gốc, điều chỉnh và giải thích |
| GitHub | Có lịch sử Git cục bộ trong `nhom3-week5.bundle` ở gốc gói ZIP | Chưa đẩy lên GitHub: chưa được cung cấp URL repository |

## Lưu ý về hiệu năng

Các chuyển động vị trí dùng transform, fade dùng opacity. Hiệu ứng gõ chữ dùng width + steps để đúng bài CSS typing; đây là ngoại lệ có thể gây layout. Màu nền và box-shadow có paint trong tương tác ngắn. Parallax fixed có thể tốn paint, đã chuyển sang scroll trên mobile. Không tuyên bố tất cả hiệu ứng đều chỉ chạy GPU.

Có `prefers-reduced-motion` để ngừng chuyển động theo cài đặt hệ điều hành. Khi tắt JavaScript, nội dung và điều hướng vẫn đọc được. Form là **minh họa**, không gửi email hay lưu dữ liệu. Nội dung nhóm lấy từ bài gốc; các tỷ lệ kỹ năng chỉ là số liệu bài tập.

## Nộp GitHub

Chưa có URL repository nên không thể cập nhật GitHub trong phiên này. Gói ZIP có mã nguồn và Git bundle chứa nhánh `feature/animation` cùng các commit mô tả hoạt động.

Nếu dùng repository đã có trên máy: sao chép các file bài này vào thư mục repository, giữ nguyên thư mục `.git` của repository, rồi chạy:

```bash
git switch -c feature/animation
git add .
git commit -m "feat: complete week 5 portfolio animations"
git push -u origin feature/animation
```

Nếu nhánh đã tồn tại, dùng `git switch feature/animation` thay cho lệnh tạo nhánh.
Có thể kiểm tra lịch sử đóng gói bằng `git clone nhom3-week5.bundle nhom3-week5` từ thư mục chứa bundle. Bản clone từ bundle chưa trỏ tới GitHub của nhóm.

## Cấu trúc

- `index.html`: portfolio và các khu vực thực hành.
- `style.css`: giữ bố cục Grid/Flexbox, thêm hiệu ứng Tuần 5.
- `script.js`: menu, lật thẻ bằng chạm, AOS/fallback, form loading.
- `assets/banner.svg`: nền parallax nội bộ.
- `week5_prompts.md`: nhật ký AI Tuần 5.
- `KIEM_TRA.md`: kết quả kiểm tra thực tế.
- `tai-lieu-tuan3/`: README, prompt log, prompt và ZIP cũ được giữ lại.
