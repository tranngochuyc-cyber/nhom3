# Nhật ký AI — Tuần 5

## Yêu cầu thực tế của người dùng

“phân tích bài trên và làm theo yêu cầu”, kèm 5 ảnh đề Tuần 5 và `nhom3-main.zip`.

Không có thêm prompt chỉnh sửa của người dùng trong phiên này. Các mục bên dưới là diễn giải triển khai của AI, không phải các câu lệnh hay thao tác do thành viên nhóm thực hiện.

## Phân tích đầu vào

Bài gốc là portfolio Tuần 3 sử dụng Grid và Flexbox. Giữ tên, MSSV, thành viên và nội dung dự án. Phát triển trên mã nguồn này để đáp ứng ba nhóm hiệu ứng bắt buộc, bốn hoạt động trên lớp và sáu bài tập tại nhà.

## Các yêu cầu triển khai đã dùng

1. Nút gửi có hover translateY(-3px), đổi màu, bóng đậm hơn; active scale(.95); dùng cubic-bezier.
2. Tạo spinner border-top khác màu, xoay 360 độ linear infinite, hiển thị trong lúc xử lý minh họa.
3. Tích hợp AOS và Animate.css qua CDN. Thêm fade-up cho section; dùng IntersectionObserver nếu CDN lỗi, tránh nội dung bị ẩn vĩnh viễn.
4. Nút Liên hệ nổi có pulse; thẻ dự án lật bằng rotateY(180deg), hỗ trợ hover và chạm; CSS typing không dùng JavaScript; nền parallax fixed; menu hamburger thành X; thanh kỹ năng tăng từ 0 bằng scaleX.
5. Tối ưu chuyển động bằng transform/opacity; giữ ngoại lệ width cho CSS typing và giải thích giới hạn. Hỗ trợ reduced motion và màn hình nhỏ.
6. Tạo README đối chiếu từng yêu cầu, kiểm tra chạy thật, đóng gói bài và lịch sử Git cục bộ. Không khẳng định đã push khi chưa có repository đích.

## Điều chỉnh theo đánh giá của AI

- Tỷ lệ kỹ năng có nhãn minh họa vì nguồn không có số liệu đánh giá năng lực.
- Form ghi rõ chưa gửi email, tránh thông báo thành công gây hiểu nhầm.
- Nền parallax dùng SVG nội bộ để không phụ thuộc ảnh ngoài; mobile tắt fixed.
- CDN có đường dự phòng offline; menu vẫn đọc được khi JavaScript tắt.
- Giữ tài liệu cũ ở thư mục riêng để không nhầm Tuần 3 với bài Tuần 5.

## Giải thích ngắn

Transition nội suy trạng thái khi hover/focus/active. Keyframes định nghĩa nhiều mốc chuyển động theo thời gian. AOS kích hoạt hiệu ứng khi phần tử vào vùng nhìn. Transform thường tránh việc tính lại bố cục do đổi top/left; opacity thường phù hợp cho fade. Các hiệu ứng không thay thế nội dung, bị giảm hoặc tắt khi hệ điều hành yêu cầu reduced motion.
