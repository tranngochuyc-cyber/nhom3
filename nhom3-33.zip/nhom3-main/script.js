'use strict';
const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
document.body.classList.add('motion-ready');
const menu = document.querySelector('.menu-toggle');
const nav = document.querySelector('#main-nav');
function closeMenu() {
  menu.setAttribute('aria-expanded', 'false');
  menu.setAttribute('aria-label', 'Mở menu');
  nav.classList.remove('is-open');
}
menu.addEventListener('click', () => {
  const open = menu.getAttribute('aria-expanded') !== 'true';
  menu.setAttribute('aria-expanded', String(open));
  menu.setAttribute('aria-label', open ? 'Đóng menu' : 'Mở menu');
  nav.classList.toggle('is-open', open);
});
nav.querySelectorAll('a').forEach(link => link.addEventListener('click', closeMenu));
document.addEventListener('keydown', event => {
  if (event.key === 'Escape' && menu.getAttribute('aria-expanded') === 'true') { closeMenu(); menu.focus(); }
});
window.matchMedia('(max-width:900px)').addEventListener('change', closeMenu);
document.querySelectorAll('.flip-toggle').forEach(button => {
  button.addEventListener('click', () => button.setAttribute('aria-pressed', String(button.getAttribute('aria-pressed') !== 'true')));
});
// CDN là đường chính; fallback giữ bài chạy được khi mở offline.
try {
  if (!window.AOS) throw new Error('AOS unavailable');
  window.AOS.init({ duration: 650, once: true, offset: 50, disable: () => reduceMotion.matches });
  document.body.classList.add('aos-enabled');
} catch (_) {
  if ('IntersectionObserver' in window && !reduceMotion.matches) {
    document.body.classList.add('reveal-fallback');
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) { entry.target.classList.remove('reveal-pending'); observer.unobserve(entry.target); }
      });
    }, { threshold: .05 });
    document.querySelectorAll('[data-aos]').forEach(section => {
      if (section.getBoundingClientRect().top > window.innerHeight) section.classList.add('reveal-pending');
      observer.observe(section);
    });
  }
}
const form = document.querySelector('.contact-form');
form.addEventListener('submit', async event => {
  event.preventDefault();
  const button = form.querySelector('.send-button');
  const label = button.querySelector('.button-label');
  const spinner = button.querySelector('.spinner');
  const status = document.querySelector('#form-status');
  if (button.disabled) return;
  button.disabled = true;
  form.setAttribute('aria-busy', 'true');
  spinner.hidden = false;
  label.textContent = 'Đang xử lý…';
  status.textContent = 'Đang chạy minh họa, không gửi dữ liệu ra ngoài.';
  await new Promise(resolve => setTimeout(resolve, 1200));
  spinner.hidden = true;
  label.textContent = 'Gửi tin nhắn';
  button.disabled = false;
  form.removeAttribute('aria-busy');
  status.textContent = 'Đã hoàn tất minh họa. Tin nhắn chưa được gửi vì chưa kết nối dịch vụ gửi thư.';
  status.classList.remove('animate__animated', 'animate__fadeIn');
  if (!reduceMotion.matches) { void status.offsetWidth; status.classList.add('animate__animated', 'animate__fadeIn'); }
});
