# Bài thực hành Tuần 4 — Design System & Tư Duy Responsive

## Chủ đề
**Multi-Device News Portal** — xây dựng trang tin tức hiển thị tốt trên Mobile, Tablet và Desktop theo tư duy Mobile First.

## Nhóm 3
| STT | Họ và tên | MSSV | Vai trò |
|---:|---|---:|---|
| 1 | **Trần Ngọc Huy** | **125001758** | Trưởng nhóm / phụ trách chính |
| 2 | Lê Văn Khoa | 125001668 | Thành viên |
| 3 | Nguyễn Minh Nhật | 125001448 | Thành viên |

## Yêu cầu đã thực hiện
- CSS Variables tại `:root`: primary, secondary, các mức xám/nền và spacing.
- Mobile First: mặc định dưới 600px, 1 cột, hamburger menu, sidebar ẩn.
- Tablet từ 600px đến 1024px: news grid 2 cột, menu ngang đơn giản, sidebar ẩn.
- Desktop trên 1024px: bố cục content + sidebar, navigation đầy đủ và search bar.
- Khu vực Chuyên mục: 1 cột Mobile → 2 cột Tablet → 4 cột Desktop bằng CSS Grid + Media Queries.
- Dùng `rem`, `%`, `max-width`, Grid/Flex và `gap`; tránh kích thước bố cục cố định.
- Refactor màu sắc và khoảng cách thành Design Tokens trong `:root`.

## Cấu trúc 5 file
```text
nhom3/
├── index.html
├── style.css
├── README.md
├── prompt.txt
└── prompt_log.md
```

## Cách chạy
Mở `index.html` trực tiếp bằng trình duyệt hoặc Live Server. Dùng DevTools → Toggle Device Toolbar để kiểm tra các mốc dưới 600px, 600–1024px và trên 1024px.


## Checklist hoàn thành Tuần 4

### CSS Variables
- Mã màu và khoảng cách được tổ chức bằng CSS Variables tại `:root`.
- Có thể thay đổi biến tại `:root` để đồng bộ giao diện toàn trang.

### Responsive
- Có thẻ `<meta name="viewport">`.
- Không xuất hiện thanh cuộn ngang.
- Hình ảnh, video và card co giãn theo chiều rộng màn hình.
- Tập trung 3 mốc chính: Mobile, Tablet `768px`, Desktop `1024px`.

### Đọc được
- Font trên Mobile tối thiểu `16px`.
- Các thành phần tương tác có touch target tối thiểu `44px`.

### GitHub / hồ sơ nộp bài
- Khi đưa lên GitHub, sử dụng nhánh `feature/responsive`.
- Nhật ký prompt AI được lưu trong `prompt_log.md` và `prompt.txt`.
